﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Forms
{
    public partial class UserControlCategory : UserControl
    {
        private string id = "";
        int indexRow;
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        DataSet dset;
        SqlDataAdapter sqlDa;
        SqlCommand scm;
        SqlCommandBuilder scb;
        DataTable dtbl;


        public UserControlCategory()
        {
            InitializeComponent();
        }

        public void EmptyBox()
        {
            txtCategoryName.Clear();
            cmbStatus.SelectedIndex = 0;
        }
        private void EmptyBox1()
        {
            txtCategoryName1.Clear();
            cmbStatus1.SelectedIndex = 0;
            id = "";
        }

        private void refresh()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            string Query = "Select * From tblCategory";
            SqlDataAdapter sqlDa = new SqlDataAdapter(Query, sqlCon);
            DataSet sqlDataset = new System.Data.DataSet();
            sqlDa.Fill(sqlDataset, "tblCategory");
            dvgCategory.DataSource = sqlDataset.Tables[0];
            lblTotal.Text = dvgCategory.Rows.Count.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtCategoryName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Kérlek add meg a márkanevet.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (cmbStatus.SelectedIndex == 0)
            {
                MessageBox.Show("Kérlek add meg az állapotot.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    SqlCommand sqlCmd = new SqlCommand("CategoryADD", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Category_Name", txtCategoryName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Category_Status", cmbStatus.Text.Trim());
                    sqlCon.Open();
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("A felvétel sikeres");
                    EmptyBox();
                }
            }
        }

        private void tpAddCategory_Enter(object sender, EventArgs e)
        {
            EmptyBox();
        }

        private void tpManageCategory_Enter(object sender, EventArgs e)
        {
            txtCategoryName.Clear();
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Category_Id, Category_Name, Category_Status FROM tblCategory", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgCategory.AutoGenerateColumns = false;
                dvgCategory.DataSource = dtbl;
            }
            lblTotal.Text = dvgCategory.Rows.Count.ToString();
        }

        private void txtSearchCategoryName_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Category_Name, Category_Status FROM tblCategory WHERE Category_Name LIKE '" + txtSearchCategoryName.Text + "%'", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgCategory.DataSource = dtbl;
            }
        }

        private void dvgCategory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dvgCategory.Rows[indexRow];
            txtCategoryName1.Text = row.Cells[1].Value.ToString();
            cmbStatus1.Text = row.Cells[2].Value.ToString();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            DataGridViewRow newDataRow = dvgCategory.Rows[indexRow];
            newDataRow.Cells[1].Value = txtCategoryName1.Text;
            newDataRow.Cells[2].Value = cmbStatus1.Text;
            MessageBox.Show("A változtatás sikeres");
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dvgCategory.Rows[indexRow];
            string Query = "DELETE FROM tblCategory WHERE Category_Id='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("A törlés sikeres");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dvgCategory.Rows[indexRow];
            string Query = "UPDATE tblCategory SET Category_Name='" + row.Cells[1].Value + "',Category_Status='" + row.Cells[2].Value + "' where Category_Id='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Feltöltve az adatbázisba");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}
