﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Log
{
    public partial class FormMain : Form
    {

        public string name = "{?}";

        public FormMain()
        {
            InitializeComponent();
        }

        private void MovePanel(Control btn)
        {
            pnlMove.Top = btn.Top;
            pnlMove.Height = btn.Height;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            lblUsername.Text = name;
            timerDateAndTime.Start();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Biztos ki akarsz jelentkezni?", "Kilépés", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(dialogResult == DialogResult.Yes)
            {
                MovePanel(btnClose);
                timerDateAndTime.Stop();
                Close();
            }
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            MovePanel(btnDashboard);
            userControlBrand2.Visible = false;
            userControlDashboard1.Visible = true;
            userControlUser11.Visible = false;
            userControlCategory1.Visible = false;
            userControlProduct21.Visible = false;
            userControlOrder1.Visible = false;
        }

        private void btnBrand_Click(object sender, EventArgs e)
        {
            MovePanel(btnBrand);
            userControlDashboard1.Visible = false;
            userControlUser11.Visible = false;
            userControlBrand2.EmptyBox();
            userControlBrand2.Visible = true;
            userControlCategory1.Visible = false;
            userControlProduct21.Visible = false;
            userControlOrder1.Visible = false;
        }

        private void btnCategory_Click(object sender, EventArgs e)
        {
            MovePanel(btnCategory);
            userControlDashboard1.Visible = false;
            userControlUser11.Visible = false;
            userControlCategory1.Visible = true;
            userControlCategory1.EmptyBox();
            userControlBrand2.Visible = false;
            userControlProduct21.Visible = false;
            userControlOrder1.Visible = false;
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            MovePanel(btnProduct);
            userControlDashboard1.Visible = false;
            userControlUser11.Visible = false;
            userControlBrand2.Visible = false;
            userControlCategory1.Visible = false;
            userControlProduct21.Visible = true;
            userControlOrder1.Visible = false;
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            MovePanel(btnOrders);
            userControlDashboard1.Visible = false;
            userControlUser11.Visible = false;
            userControlBrand2.Visible = false;
            userControlCategory1.Visible = false;
            userControlProduct21.Visible = false;
            userControlOrder1.Emptybox();
            userControlOrder1.Visible = true;
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
           
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            MovePanel(btnUsers);
            userControlDashboard1.Visible = false;
            userControlBrand2.Visible = false;
            userControlUser11.Visible = true;
            userControlCategory1.Visible = false;
            userControlProduct21.Visible = false;
            userControlOrder1.Visible = false;
        }

        private void timerDateAndTime_Tick(object sender, EventArgs e)
        {
            lblTimeAndDate.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
