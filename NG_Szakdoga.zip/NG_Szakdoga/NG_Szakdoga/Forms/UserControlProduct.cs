﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Forms
{
    public partial class UserControlProduct : UserControl
    {
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        byte[] image;
        ImageConverter ImageConventer;
        MemoryStream memoryStream;

        public UserControlProduct()
        {
            InitializeComponent();
            BrandAutoFill();
            CategoryAutoFill();
            ImageConventer = new ImageConverter();
        }

        private void ImageUpload(PictureBox picture)
        {
            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    picture.Image = Image.FromFile(openFileDialog.FileName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba a kép feltöltése során.", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void EmptyBox()
        {
            txtProductName.Clear();
            picPhoto.Image = null;
            nudRate.Value = 0;
            nudQuantity.Value = 0;
            cmbBrand.Items.Clear();
            cmbBrand.Items.Add("--VÁLASZD KI--");
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Brand_Name FROM tblBrand WHERE Brand_Status = 'Elérhető' ORDER BY Brand_Name;", sqlCon);
            }
            cmbBrand.SelectedIndex = 0;
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add("--VÁLASZD KI--");
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Category_Name FROM tblCategory WHERE Category_Status = 'Elérhető' ORDER BY Category_Name;", sqlCon);
            }
            cmbCategory.SelectedIndex = 0;
            cmbStatus.SelectedIndex = 0;
        }

        private void EmptyBox1()
        {
            txtProductName1.Clear();
            picPhoto1.Image = null;
            nudRate1.Value = 0;
            nudQuantity1.Value = 0;
            BrandAutoFill();
            CategoryAutoFill();
            cmbStatus1.SelectedIndex = 0;
        }

        private void BrandAutoFill()
        {
            cmbBrand1.Items.Clear();
            cmbBrand1.Items.Add("--VÁLASZD KI--");
            string Query = "SELECT Brand_Name FROM tblBrand WHERE Brand_Status = 'Elérhető' ORDER BY Brand_Name;";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    string BrandName = sqlReader.GetString("Brand_Name");
                    cmbBrand.Items.Add(BrandName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            cmbBrand1.SelectedIndex = 0;
        }

        private void CategoryAutoFill()
        {
            cmbCategory1.Items.Clear();
            cmbCategory1.Items.Add("--VÁLASZD KI--");
            string Query = "SELECT Category_Name FROM tblCategory WHERE Category_Status = 'Elérhető' ORDER BY Category_Name;";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    string BrandName = sqlReader.GetString("Category_Name");
                    cmbBrand.Items.Add(BrandName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            cmbCategory1.SelectedIndex = 0;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            ImageUpload(picPhoto);
        }

        private void btnBrowse1_Click(object sender, EventArgs e)
        {
            ImageUpload(picPhoto1);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtProductName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Kérlek add meg a temék nevét!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (picPhoto.Image == null)
            {
                MessageBox.Show("Kérlek válassz egy képet!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (nudRate.Value==0)
            {
                MessageBox.Show("Kérlek add meg a termék árát!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (nudQuantity.Value == 0)
            {
                MessageBox.Show("Kérlek add meg a termék mennyiségét!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (cmbBrand.SelectedIndex ==0)
            {
                MessageBox.Show("Kérlek válassz egy márkát!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (cmbCategory.SelectedIndex == 0)
            {
                MessageBox.Show("Kérlek válassz egy kategóriát!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (cmbStatus.SelectedIndex == 0)
            {
                MessageBox.Show("Kérlek válasszd ki az állapotát!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    SqlCommand sqlCmd = new SqlCommand("ProductADD", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Product_Image", picPhoto);
                    sqlCmd.Parameters.AddWithValue("@Product_Rate", nudRate.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Product_Quantity", nudQuantity.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Product_Brand", cmbBrand.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Product_Category", cmbCategory.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Product_Status", cmbStatus.Text.Trim());
                    sqlCon.Open();
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("A felvétel sikeres");
                    EmptyBox();
                }
            }
        }
    }
}
