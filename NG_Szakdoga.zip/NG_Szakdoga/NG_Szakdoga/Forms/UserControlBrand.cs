﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Forms
{
    public partial class UserControlBrand : UserControl
    {
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        private string id = "";
        int indexRow;
        DataSet dset;
        SqlDataAdapter sqlDa;
        SqlCommand scm;
        SqlCommandBuilder scb;
        DataTable dtbl;

        public UserControlBrand()
        {
            InitializeComponent();
        }
        public void EmptyBox()
        {
            txtBrandName.Clear();
            cmbStatus.SelectedIndex = 0;
        }
        private void EmptyBox1()
        {
            txtBrandName1.Clear();
            cmbStatus1.SelectedIndex = 0;
            id = "";
        }

        private void refresh()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            string Query = "Select * From tblBrand";
            SqlDataAdapter sqlDa = new SqlDataAdapter(Query, sqlCon);
            DataSet sqlDataset = new System.Data.DataSet();
            sqlDa.Fill(sqlDataset, "tblBrand");
            dvgBrand.DataSource = sqlDataset.Tables[0];
            lblTotal.Text = dvgBrand.Rows.Count.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtBrandName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Kérlek add meg a márkanevet.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (cmbStatus.SelectedIndex == 0)
            {
                MessageBox.Show("Kérlek add meg az állapotot.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    SqlCommand sqlCmd = new SqlCommand("BrandADD", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Brand_Name", txtBrandName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Brand_Status", cmbStatus.Text.Trim());
                    sqlCon.Open();
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("A felvétel sikeres");
                    EmptyBox();
                }
            }
        }

        private void tpAddBrand_Enter(object sender, EventArgs e)
        {
            EmptyBox();
        }

        private void tpManageBrand_Enter(object sender, EventArgs e)
        {
            txtSearchBrandName.Clear();
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Brand_Id, Brand_Name, Brand_Status FROM tblBrand", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgBrand.AutoGenerateColumns = false;
                dvgBrand.DataSource = dtbl;
            }
            lblTotal.Text = dvgBrand.Rows.Count.ToString();
        }

        private void txtSearchBrandName_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Brand_Name, Brand_Status FROM tblBrand WHERE Brand_Name LIKE '" + txtSearchBrandName.Text + "%'", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgBrand.DataSource = dtbl;
            }
        }

        private void dvgBrand_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dvgBrand.Rows[indexRow];
            txtBrandName1.Text = row.Cells[1].Value.ToString();
            cmbStatus1.Text = row.Cells[2].Value.ToString();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            DataGridViewRow newDataRow = dvgBrand.Rows[indexRow];
            newDataRow.Cells[1].Value = txtBrandName1.Text;
            newDataRow.Cells[2].Value = cmbStatus1.Text;
            MessageBox.Show("A változtatás sikeres");
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            
            DataGridViewRow row = dvgBrand.Rows[indexRow];
            string Query = "UPDATE tblBrand SET Brand_Name='" + row.Cells[1].Value + "',Brand_Status='" + row.Cells[2].Value + "' where Brand_Id='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Feltöltve az adatbázisba");
                while (sqlReader.Read())
                {
                    
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dvgBrand.Rows[indexRow];
            string Query = "DELETE FROM tblBrand WHERE Brand_Id='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("A törlés sikeres");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}
