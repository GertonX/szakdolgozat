﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace NG_Szakdoga.Log
{
    public partial class FormRegistracion : Form
    {

        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";

        public FormRegistracion()
        {
            InitializeComponent();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtFelhasznalonev.Text == "" || txtJelszo.Text == "" || txtJelszoIsm.Text == "" || txtVezeteknev.Text == "" || txtKeresztnev.Text == "" || txtEmail.Text== "" || txtTelefonszam.Text == "" || txtCim.Text == "" )
                MessageBox.Show("Kérlek töltsd ki az adatokat");
            else if (txtJelszo.Text != txtJelszoIsm.Text)
                MessageBox.Show("A jelszavak nem egyeznek");
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    SqlCommand sqlCmd = new SqlCommand("UserADD2", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Vezeteknev", txtVezeteknev.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Keresztnev", txtKeresztnev.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Cim", txtCim.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Telefonszam", txtTelefonszam.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Felhasznalonev", txtFelhasznalonev.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Jelszo", txtJelszo.Text.Trim());
                    sqlCon.Open();
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Regisztráció sikeres");
                    Clear();
                }
            }
        }
        void Clear()
        {
            txtVezeteknev.Text = txtKeresztnev.Text = txtEmail.Text = txtCim.Text = txtTelefonszam.Text
                = txtFelhasznalonev.Text = txtJelszo.Text = txtJelszoIsm.Text = "";
        }
    }
}
