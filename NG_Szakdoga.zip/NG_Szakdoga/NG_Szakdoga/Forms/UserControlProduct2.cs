﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Forms
{
    public partial class UserControlProduct2 : UserControl
    {
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        byte[] images;
        ImageConverter ImageConventer;
        MemoryStream memoryStream;
        SqlCommand SqlCommand;
        string imgLocation ="";
        int indexRow;

        public UserControlProduct2()
        {
            InitializeComponent();
            
        }

        private void refresh()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            string Query = "Select * From tblProduct";
            SqlDataAdapter sqlDa = new SqlDataAdapter(Query, sqlCon);
            DataSet sqlDataset = new System.Data.DataSet();
            sqlDa.Fill(sqlDataset, "tblProduct");
            dvgProduct.DataSource = sqlDataset.Tables[0];
            lblTotal.Text = dvgProduct.Rows.Count.ToString();
        }

        private void ImageUpload(PictureBox picture)
        {
            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    picture.Image = Image.FromFile(openFileDialog.FileName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba a kép feltöltése során.", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void EmptyBox()
        {
            txtProductName.Clear();
            picPhoto.Image = null;
            nudRate.Value = 0;
            nudQuantity.Value = 0;
            cmbBrand.Items.Clear();
            cmbBrand.Items.Add("--VÁLASZD KI--");
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Brand_Name FROM tblBrand WHERE Brand_Status = 'Elérhető' ORDER BY Brand_Name;", sqlCon);
            }
            cmbBrand.SelectedIndex = 0;
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add("--VÁLASZD KI--");
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Category_Name FROM tblCategory WHERE Category_Status = 'Elérhető' ORDER BY Category_Name;", sqlCon);
            }
            cmbCategory.SelectedIndex = 0;
            cmbStatus.SelectedIndex = 0;
        }

        private void EmptyBox1()
        {
            txtProductName1.Clear();
            picPhoto1.Image = null;
            nudRate1.Value = 0;
            nudQuantity1.Value = 0;
            BrandAutoFill();
            CategoryAutoFill();
            cmbStatus1.SelectedIndex = 0;
        }

        private void BrandAutoFill()
        {
            cmbBrand1.Items.Clear();
            cmbBrand.Items.Clear();
            cmbBrand1.Items.Add("--VÁLASZD KI--");
            cmbBrand.Items.Add("--VÁLASZD KI--");
            string Query = "SELECT Brand_Name FROM tblBrand WHERE Brand_Status = 'Elérhető' ORDER BY Brand_Name;";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    string BrandName = sqlReader.GetString("Brand_Name");
                    cmbBrand.Items.Add(BrandName);
                    cmbBrand1.Items.Add(BrandName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            cmbBrand1.SelectedIndex = 0;
            cmbBrand.SelectedIndex = 0;
        }

        private void CategoryAutoFill()
        {
            cmbCategory1.Items.Clear();
            cmbCategory.Items.Clear();
            cmbCategory1.Items.Add("--VÁLASZD KI--");
            cmbCategory.Items.Add("--VÁLASZD KI--");
            string Query = "SELECT Category_Name FROM tblCategory WHERE Category_Status = 'Elérhető' ORDER BY Category_Name;";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    string CategoryName = sqlReader.GetString("Category_Name");
                    cmbCategory.Items.Add(CategoryName);
                    cmbCategory1.Items.Add(CategoryName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            cmbCategory1.SelectedIndex = 0;
            cmbCategory.SelectedIndex = 0;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            ImageUpload(picPhoto);
            imgLocation = openFileDialog.FileName.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            byte[] images = null;
            FileStream Streem = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
            BinaryReader brs = new BinaryReader(Streem);
            images = brs.ReadBytes((int)Streem.Length);

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                SqlCommand sqlCmd = new SqlCommand("ProductADD", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Product_Rate", nudRate.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Product_Quantity", nudQuantity.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Product_Brand", cmbBrand.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Product_Category", cmbCategory.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Product_Status", cmbStatus.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Product_Image", images);
                sqlCon.Open();
                sqlCmd.ExecuteNonQuery();
                MessageBox.Show("A felvétel sikeres");
                EmptyBox();
            }
        }

        private void UserControlProduct2_Load(object sender, EventArgs e) 
        {
            //BrandAutoFill();
            //CategoryAutoFill();
            //nem jó a combobox fill

            /*
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            SqlCommand sqlCmd = new SqlCommand("SELECT Brand_Name FROM tblBrand WHERE Brand_Status = 'Elérhető' ORDER BY Brand_Name;", sqlCon);
            SqlDataAdapter sqlDa = new SqlDataAdapter();
            sqlDa.SelectCommand = sqlCmd;
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            DataRow itemrow = dtbl.NewRow();
            itemrow[0] = "--VÁLASZD KI--";
            dtbl.Rows.InsertAt(itemrow, 1);

            cmbBrand.DataSource = dtbl;
            cmbBrand.DisplayMember = "Brand_Name";
            cmbBrand.ValueMember = "Brand_Id";
            */

            /*
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            var command = new Microsoft.Data.SqlClient.SqlCommand();
            command.Connection = sqlCon;
            command.CommandType = CommandType.Text;
            command.CommandText = "SELECT Brand_Name FROM tblBrand";

            var adapter = new Microsoft.Data.SqlClient.SqlDataAdapter(command);
            var dataset = new DataSet();
            adapter.Fill(dataset);
            DataTable dtbl = dataset.Tables[0];
            for (int i = 0; i < dataset.Tables[0].Rows.Count; i++)
            {
                cmbBrand.Items.Add(dataset.Tables[0].Rows[i][0].ToString());
                sqlCon.Close();
            }
            */
        }

        private void tpManageProduct_Enter(object sender, EventArgs e)
        {
            txtSearchProductName.Clear();
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Product_Id, Product_Name, Product_Image, Product_Rate, Product_Quantity, Product_Brand, Product_Category, Product_Status FROM tblProduct", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgProduct.AutoGenerateColumns = false;
                dvgProduct.DataSource = dtbl;
            }
            lblTotal.Text = dvgProduct.Rows.Count.ToString();
        }

        private void txtSearchProductName_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Product_Id, Product_Name, Product_Image, Product_Rate, Product_Quantity, Product_Brand, Product_Category, Product_Status FROM tblProduct WHERE Product_Name LIKE '" + txtSearchProductName.Text + "%'", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgProduct.DataSource = dtbl;
            }
        }

        private void dvgProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            

            indexRow = e.RowIndex;
            DataGridViewRow row = dvgProduct.Rows[indexRow];
            byte[] imgData = (byte[])row.Cells[1].Value;
            MemoryStream ms = new MemoryStream(imgData);
            picPhoto1.Image = Image.FromStream(ms);
            txtProductName1.Text = row.Cells[2].Value.ToString();
            nudRate1.Text = row.Cells[3].Value.ToString();
            nudQuantity1.Text = row.Cells[4].Value.ToString();
            cmbBrand1.Text = row.Cells[5].Value.ToString();
            cmbCategory1.Text = row.Cells[6].Value.ToString();
            cmbStatus1.Text = row.Cells[7].Value.ToString();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            DataGridViewRow newDataRow = dvgProduct.Rows[indexRow];
            newDataRow.Cells[2].Value = txtProductName1.Text;
            newDataRow.Cells[3].Value = nudRate1.Text;
            newDataRow.Cells[4].Value = nudQuantity1.Text;
            newDataRow.Cells[5].Value = cmbBrand1.Text;
            newDataRow.Cells[6].Value = cmbCategory1.Text;
            newDataRow.Cells[7].Value = cmbStatus1.Text;
            MessageBox.Show("A változtatás sikeres");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /*
            byte[] images = null;
            FileStream Streem = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
            BinaryReader brs = new BinaryReader(Streem);
            images = brs.ReadBytes((int)Streem.Length);
            */

            DataGridViewRow row = dvgProduct.Rows[indexRow];
            string Query = "UPDATE tblProduct SET Product_Name ='" + row.Cells[2].Value + "',Product_Rate='" + row.Cells[3].Value + "',Product_Quantity='" + row.Cells[4].Value + "', Product_Brand='" + row.Cells[5].Value + "', Product_Category='" + row.Cells[6].Value + "', Product_Status='" + row.Cells[7].Value + "' where Product_Id='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Feltöltve az adatbázisba");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dvgProduct.Rows[indexRow];
            string Query = "DELETE FROM tblProduct WHERE Product_Id='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("A törlés sikeres");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tcProduct_Enter(object sender, EventArgs e)
        {
            BrandAutoFill();
            CategoryAutoFill();
            cmbStatus.SelectedIndex = 0;
            cmbStatus1.SelectedIndex = 0;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}
