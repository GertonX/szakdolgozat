﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Log
{
    public partial class UserControlDashboard : UserControl
    {
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        SqlCommand cmd;

        public UserControlDashboard()
        {
            InitializeComponent();
        }

        public void TotalProductCount()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            string Query = "SELECT COUNT(Product_Id) FROM tblProduct;";
            cmd = new SqlCommand(Query, sqlCon);
            Int32 tp = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();
            sqlCon.Close();
            lblTotalProduct.Text = tp.ToString();
        }

        public void TotalOrdersCount()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            string Query = "SELECT COUNT(Orders_Id) FROM tblOrders2;";
            cmd = new SqlCommand(Query, sqlCon);
            Int32 to = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();
            sqlCon.Close();
            lblTotalOrders.Text = to.ToString();
        }

        public void LowStocksCount()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            string Query = "SELECT COUNT(Product_Id) FROM tblProduct WHERE Product_Status ='Nem elérhető';";
            cmd = new SqlCommand(Query, sqlCon);
            Int32 ls = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();
            sqlCon.Close();
            lblLowStock.Text = ls.ToString();
        }

        public void TotalRevenueCount()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            string Query = "SELECT SUM(Orders_Total) FROM tblOrders2;";
            cmd = new SqlCommand(Query, sqlCon);
            Int32 tr = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();
            sqlCon.Close();
            lblTotalRevenue.Text = tr.ToString();
        }

        private void UserControlDashboard_Load(object sender, EventArgs e)
        {
            
        }

        private void UserControlDashboard_Enter(object sender, EventArgs e)
        {
            TotalProductCount();
            TotalOrdersCount();
            LowStocksCount();
            TotalRevenueCount();
        }

        private void UserControlDashboard_Load_1(object sender, EventArgs e)
        {
            TotalProductCount();
            TotalOrdersCount();
            LowStocksCount();
            TotalRevenueCount();
        }
    }
}
