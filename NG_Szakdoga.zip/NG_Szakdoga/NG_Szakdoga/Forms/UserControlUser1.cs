﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Forms
{
    public partial class UserControlUser1 : UserControl
    {

        private string id = "";
        int indexRow;
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        DataSet dset;
        SqlDataAdapter sqlDa;
        SqlCommand scm;
        SqlCommandBuilder scb;
        DataTable dtbl;

        public UserControlUser1()
        {
            InitializeComponent();
        }

        private void refresh()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            string Query = "Select * From tblUser2";
            SqlDataAdapter sqlDa = new SqlDataAdapter(Query, sqlCon);
            DataSet sqlDataset = new System.Data.DataSet();
            sqlDa.Fill(sqlDataset, "tblUser2");
            dvgUser.DataSource = sqlDataset.Tables[0];
            lblTotal.Text = dvgUser.Rows.Count.ToString();
        }

        private void tpManageUser_Enter(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT UserID, Vezeteknev, Keresztnev, Email, Cim, Telefonszam, Felhasznalonev, Jelszo FROM tblUser2", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgUser.AutoGenerateColumns = false;
                dvgUser.DataSource = dtbl;
            }
            lblTotal.Text = dvgUser.Rows.Count.ToString();
        }

        private void txtSearchUserName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dvgUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {

        }

        private void tpManageUser_Enter_1(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT UserID, Vezeteknev, Keresztnev, Email, Cim, Telefonszam, Felhasznalonev, Jelszo FROM tblUser2", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgUser.AutoGenerateColumns = false;
                dvgUser.DataSource = dtbl;
            }
            lblTotal.Text = dvgUser.Rows.Count.ToString();
        }

        private void dvgUser_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dvgUser.Rows[indexRow];
            txtUserName.Text = row.Cells[1].Value.ToString();
            txtEmail.Text = row.Cells[2].Value.ToString();
            txtPassword.Text = row.Cells[3].Value.ToString();
            txtVezeteknev.Text = row.Cells[4].Value.ToString();
            txtKeresztnev.Text = row.Cells[5].Value.ToString();
            txtTelefonszam.Text = row.Cells[6].Value.ToString();
            txtCim.Text = row.Cells[7].Value.ToString();
        }

        private void txtSearchUserName_TextChanged_1(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT UserID, Vezeteknev, Keresztnev, Email, Cim, Telefonszam, Felhasznalonev, Jelszo FROM tblUser2 WHERE Felhasznalonev LIKE '" + txtSearchUserName.Text + "%'", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgUser.DataSource = dtbl;
            }
        }

        private void btnChange_Click_1(object sender, EventArgs e)
        {
            DataGridViewRow newDataRow = dvgUser.Rows[indexRow];
            newDataRow.Cells[1].Value = txtUserName.Text;
            newDataRow.Cells[2].Value = txtEmail.Text;
            newDataRow.Cells[3].Value = txtPassword.Text;
            newDataRow.Cells[4].Value = txtVezeteknev.Text;
            newDataRow.Cells[5].Value = txtKeresztnev.Text;
            newDataRow.Cells[6].Value = txtTelefonszam.Text;
            newDataRow.Cells[7].Value = txtCim.Text;
            MessageBox.Show("A változtatás sikeres");
        }

        private void tcManageUser_Enter(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT UserID, Vezeteknev, Keresztnev, Email, Cim, Telefonszam, Felhasznalonev, Jelszo FROM tblUser2", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgUser.AutoGenerateColumns = false;
                dvgUser.DataSource = dtbl;
            }
            lblTotal.Text = dvgUser.Rows.Count.ToString();
        }

        private void btn_Update_Click_1(object sender, EventArgs e)
        {
            DataGridViewRow row = dvgUser.Rows[indexRow];
            string Query = "UPDATE tblUser2 SET Felhasznalonev='" + row.Cells[1].Value + "',Email='" + row.Cells[2].Value + "',Jelszo='" + row.Cells[3].Value + "', Vezeteknev='" + row.Cells[4].Value + "', Keresztnev='" + row.Cells[5].Value + "', Telefonszam='" + row.Cells[6].Value + "', Cim='" + row.Cells[7].Value + "' where UserID='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Feltöltve az adatbázisba");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            DataGridViewRow row = dvgUser.Rows[indexRow];
            string Query = "DELETE FROM tblUser2 WHERE UserID='" + row.Cells[0].Value + "';";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                MessageBox.Show("A törlés sikeres");
                while (sqlReader.Read())
                {

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UserControlUser1_Load(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT UserID, Vezeteknev, Keresztnev, Email, Cim, Telefonszam, Felhasznalonev, Jelszo FROM tblUser2", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgUser.AutoGenerateColumns = false;
                dvgUser.DataSource = dtbl;
            }
            lblTotal.Text = dvgUser.Rows.Count.ToString();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}
