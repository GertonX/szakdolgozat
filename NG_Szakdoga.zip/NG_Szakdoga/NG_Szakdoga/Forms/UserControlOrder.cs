﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Forms
{
    public partial class UserControlOrder : UserControl
    {
        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";
        int indexRow;
        SqlCommand sqlCmd;
        public UserControlOrder()
        {
            InitializeComponent();
        }

        public void Emptybox()
        {
            dtpDate.Value = DateTime.Now;
            ProductAutoFill();
            CustomerNameAutoFill();
            dvgProductList.Rows.Clear();
            txtGrandTotal.Text = "0";
            cmbPayment.SelectedIndex = 0;
        }


        private void ProductAutoFill()
        {
            cmbProduct.Items.Clear();
            cmbProduct.Items.Add("--VÁLASZD KI--");

            string Query = "SELECT Product_Name FROM tblProduct WHERE Product_Status = 'Elérhető' ORDER BY Product_Name;";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    string ProductName = sqlReader.GetString("Product_Name");
                    cmbProduct.Items.Add(ProductName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba a termékek beillesztése közben!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            cmbProduct.SelectedIndex = 0;
            txtRate.Clear();
            nudQuantity.Value = 0;
            txtTotal.Clear();
            txtId.Clear();

        }

        private void CustomerNameAutoFill()
        {
            cmbCustomerName.Items.Clear();
            cmbCustomerName.Items.Add("--VÁLASZD KI--");

            string Query = "SELECT Felhasznalonev FROM tblUser2 ORDER BY Felhasznalonev;";
            SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
            SqlDataReader sqlReader;
            try
            {
                sqlCon.Open();
                sqlReader = sqlCommand.ExecuteReader();
                while (sqlReader.Read())
                {
                    string CustomerName = sqlReader.GetString("Felhasznalonev");
                    cmbCustomerName.Items.Add(CustomerName);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba", "Hiba a felhasználók beillesztése közben!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            cmbCustomerName.SelectedIndex = 0;

        }

        private void refresh()
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            string Query = "Select * From tblOrders2";
            SqlDataAdapter sqlDa = new SqlDataAdapter(Query, sqlCon);
            DataSet sqlDataset = new System.Data.DataSet();
            sqlDa.Fill(sqlDataset, "tblOrders2");
            dvgOrders.DataSource = sqlDataset.Tables[0];
            lblTotal.Text = dvgOrders.Rows.Count.ToString();
        }

        public void clearAll()
        {
            dvgProductList.Rows.Clear();
            txtGrandTotal.Text = "0";
        }

        public void GrandTotalCount()
        {
            int sum = 0;
            for (int i = 0; i < dvgOrders.Rows.Count; i++)
            {
                sum += Convert.ToInt32(dvgOrders.Rows[i].Cells[5].Value);
                txtGrandTotal1.Text = sum.ToString();
            }
        }


        RichTextBox richTextBox = new RichTextBox();

        private void Receipt()
        {
            richTextBox.Clear();
            richTextBox.Text += "\t\t\t\t          PC Alkatrész Bolt\n";
            richTextBox.Text += "************************************************************************************************************\n\n";
            richTextBox.Text += "************************************************************************************************************\n";
            richTextBox.Text += "   Felhasználó\tTermék\t\tTermék Ára/db\t\tTermék mennyisége\t\tÖsszesen\t\tFizetőeszköz\t\tRendelés dátuma\n";
            for (int i = 0; i < dvgProductList.Rows.Count; i++)
            {
                for (int j = 0; j < dvgProductList.Columns.Count - 1; j++)
                    richTextBox.Text += dvgProductList.Rows[i].Cells[j].Value.ToString() + "\t\t";
                richTextBox.Text += "\n"; 
            }
            richTextBox.Text += "************************************************************************************************************\n\n";
            richTextBox.Text += "\t\t\t\t\t\t\t\t Végösszeg: " + txtGrandTotal.Text + " Ft\n";

        }

        int oTotal = 0;

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(cmbProduct.SelectedIndex == 0)
            {
                MessageBox.Show("Kérlek válassz ki egy terméket.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (nudQuantity.Value == 0)
            {
                MessageBox.Show("Kérlek add meg a termék mennyiségét.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                if(nudQuantity.Value>0)
                {
                    int rate, total;
                    Int32.TryParse(txtRate.Text, out rate);
                    Int32.TryParse(txtTotal.Text, out total);
                    if(dvgProductList.Rows.Count != 0)
                    {
                        foreach (DataGridViewRow rows in dvgProductList.Rows)
                        {
                            if(rows.Cells[1].Value.ToString() == cmbProduct.SelectedItem.ToString())
                            {
                                int quantity = Convert.ToInt32(rows.Cells[3].Value.ToString());
                                int total1 = Convert.ToInt32(rows.Cells[4].Value.ToString());
                                quantity += Convert.ToInt32(nudQuantity.Value);
                                total1 += total;
                                rows.Cells[3].Value = quantity;
                                rows.Cells[4].Value = total1;
                                ProductAutoFill();
                            }
                        }
                        if (cmbProduct.SelectedIndex != 0)
                        {
                            txtTotal.Text = (rate * Convert.ToInt32(nudQuantity.Value)).ToString();
                            string[] row =
                            {
                                        cmbCustomerName.SelectedItem.ToString(), cmbProduct.SelectedItem.ToString(), txtRate.Text, nudQuantity.Value.ToString(), txtTotal.Text, cmbPayment.SelectedItem.ToString(), dtpDate.Value.ToString("yyyy-MM-dd"), txtId.Text
                                    };
                            dvgProductList.Rows.Add(row);
                            ProductAutoFill();
                        }
                    }
                    else
                    {
                        txtTotal.Text = (rate * Convert.ToInt32(nudQuantity.Value)).ToString();
                    string[] row =
                    {
                                        cmbCustomerName.SelectedItem.ToString(), cmbProduct.SelectedItem.ToString(), txtRate.Text, nudQuantity.Value.ToString(), txtTotal.Text, cmbPayment.SelectedItem.ToString(), dtpDate.Value.ToString("yyyy-MM-dd"), txtId.Text
                                    };
                        dvgProductList.Rows.Add(row);
                        ProductAutoFill();
                    }
                }
                txtGrandTotal.Text = oTotal.ToString();
            }
            foreach (DataGridViewRow rows in dvgProductList.Rows)
            {
                oTotal += Convert.ToInt32(rows.Cells[4].Value.ToString());
                txtGrandTotal.Text = oTotal.ToString();
            }
            oTotal = 0;
        }

        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCmd = new SqlCommand("SELECT * FROM tblProduct WHERE Product_Name ='" + cmbProduct.Text + "'",sqlCon);
            sqlCon.Open();
            sqlCmd.ExecuteNonQuery();
            SqlDataReader sqlReader;
            sqlReader = sqlCmd.ExecuteReader();
            while(sqlReader.Read())
            {
                string rate = (string)sqlReader["Product_Rate"].ToString();
                txtRate.Text = rate;
                string id = (string)sqlReader["Product_Id"].ToString();
                txtId.Text = id;
            }
        }

        private void nudQuantity_ValueChanged(object sender, EventArgs e)
        {
            int rate;
            Int32.TryParse(txtRate.Text, out rate);
            txtTotal.Text = (rate * Convert.ToInt32(nudQuantity.Value)).ToString();
        }

        private void dvgProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 8)
            {
                int rowIndex = dvgProductList.CurrentCell.RowIndex;
                dvgProductList.Rows.RemoveAt(rowIndex);
                if (dvgProductList.Rows.Count != 0)
                {
                    foreach (DataGridViewRow rows in dvgProductList.Rows)
                    {
                        oTotal += Convert.ToInt32(rows.Cells[4].Value.ToString());
                        txtGrandTotal.Text = oTotal.ToString();
                    }
                }
                else
                    txtGrandTotal.Text = "0";
                oTotal = 0;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbCustomerName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Kérlek add meg a felhasználónevet.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (cmbPayment.SelectedIndex == 0)
            {
                MessageBox.Show("Kérlek válaszd ki a fizetési módot.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                
                SqlConnection sqlCon = new SqlConnection(connectionString);
                for (int i = 0; i < dvgProductList.Rows.Count; i++)
                {
                    sqlCmd = new SqlCommand(@"INSERT INTO tblOrders2 VALUES('" + dvgProductList.Rows[i].Cells[0].Value + "','" + dvgProductList.Rows[i].Cells[1].Value + "','" + dvgProductList.Rows[i].Cells[2].Value + "','" + dvgProductList.Rows[i].Cells[3].Value + "','" + dvgProductList.Rows[i].Cells[4].Value + "','" + dvgProductList.Rows[i].Cells[5].Value + "','" + dvgProductList.Rows[i].Cells[6].Value + "','" + dvgProductList.Rows[i].Cells[7].Value +"')", sqlCon);
                    sqlCon.Open();
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    
                }
                MessageBox.Show("A felvétel sikeres");
            }
            clearAll();
        }

        private void btnReceipt_Click(object sender, EventArgs e)
        {
            Receipt();
            printPreviewDialog.Document = printDocument;
            printDocument.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 500, 600);
            printPreviewDialog.ShowDialog();
        }

        private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(richTextBox.Text, new Font("Segoe UI", 6, FontStyle.Regular), Brushes.Black, new Point(10, 10));
        }

        private void tpManageOrders_Enter(object sender, EventArgs e)
        {
            txtSearchCustomerName.Clear();
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT tblOrders2.Orders_Id, tblOrders2.Customer_Name, tblOrders2.Product_Name, tblOrders2.Product_Price, tblOrders2.Product_Quantity, tblOrders2.Orders_Total, tblOrders2.Orders_Payment, tblOrders2.Orders_Date, tblOrders2.Id_Product_Id FROM tblOrders2 INNER JOIN tblProduct ON tblOrders2.Id_Product_Id = tblProduct.Product_Id", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgOrders.AutoGenerateColumns = false;
                dvgOrders.DataSource = dtbl;
            }
            lblTotal.Text = dvgOrders.Rows.Count.ToString();
            GrandTotalCount();
        }

        private void txtSearchCustomerName_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT tblOrders2.Orders_Id, tblOrders2.Customer_Name, tblOrders2.Product_Name, tblOrders2.Product_Price, tblOrders2.Product_Quantity, tblOrders2.Orders_Total, tblOrders2.Orders_Payment, tblOrders2.Orders_Date, tblOrders2.Id_Product_Id FROM tblOrders2 INNER JOIN tblProduct ON tblOrders2.Id_Product_Id = tblProduct.Product_Id WHERE tblOrders2.Customer_Name LIKE '" + txtSearchCustomerName.Text + "%'", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dvgOrders.AutoGenerateColumns = false;
                dvgOrders.DataSource = dtbl;
            }
            lblTotal.Text = dvgOrders.Rows.Count.ToString();
            GrandTotalCount();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        private void dvgOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex == 9)
            {
                DataGridViewRow row = dvgOrders.Rows[e.RowIndex];
                string Query = "DELETE FROM tblOrders2 WHERE Orders_Id='" + row.Cells[0].Value + "';";
                SqlConnection sqlCon = new SqlConnection(connectionString);
                SqlCommand sqlCommand = new SqlCommand(Query, sqlCon);
                SqlDataReader sqlReader;
                try
                {
                    sqlCon.Open();
                    sqlReader = sqlCommand.ExecuteReader();
                    MessageBox.Show("A törlés sikeres");
                    while (sqlReader.Read())
                    {

                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Hiba a törlés során.", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
