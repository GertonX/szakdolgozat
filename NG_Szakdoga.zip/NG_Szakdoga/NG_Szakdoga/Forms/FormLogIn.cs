﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NG_Szakdoga.Log
{
    public partial class FormLogIn : Form
    {

        string connectionString = @"Data Source=GERGO-PC;Initial Catalog=NG_Szakdoga;Integrated Security=True;";

        public FormLogIn()
        {
            InitializeComponent();
        }

        private void EmptyBox()
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void picShow_Click(object sender, EventArgs e)
        {
            if(picShow.Visible == true)
            {
                txtPassword.UseSystemPasswordChar = false;
                picShow.Visible = false;
                picHide.Visible = true;
            }
        }

        private void picHide_Click(object sender, EventArgs e)
        {
            if (picHide.Visible == true)
            {
                txtPassword.UseSystemPasswordChar = true;
                picShow.Visible = true;
                picHide.Visible = false;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            string query = "Select * from tblUser2 Where Felhasznalonev = '" + txtUsername.Text.Trim() + "' and Jelszo = '" + txtPassword.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlCon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if(dtbl.Rows.Count == 1)
            {
                MessageBox.Show("A belépés sikeres.", "Belépés", MessageBoxButtons.OK, MessageBoxIcon.Information);
                FormMain formMain = new FormMain();
                formMain.name = txtUsername.Text;
                formMain.ShowDialog();
                EmptyBox();
            }
            else if (txtUsername.Text.Trim()== string.Empty)
            {
                MessageBox.Show("Kérlek add meg a felhasználónevedet!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (txtPassword.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Kérlek add meg a jelszavadat!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                MessageBox.Show("Felhasználónév vagy jelszó hibás!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_Registracion_Click(object sender, EventArgs e)
        {
            FormRegistracion f2 = new FormRegistracion();
            f2.ShowDialog();
        }
    }
}
